## REQUIREMENTS

* None on the server during CTF

* For building: Turbo C++ under DOSBox and Python. Makefile has building disabled due to the DOS part.

* For testing: No tests (DOSBox instrumentation would be required - another time). On the flipside it Seems to Work(TM) and the algorithm used is unambiguous.

![](mirage.gif)

